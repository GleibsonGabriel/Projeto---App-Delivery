<?php
// cadastro.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $endereco = $_POST['endereco'];

    // Campo onde iriamos inserir os dados do cliente.

    echo "<p>Cadastro realizado com sucesso!</p>";
}
?>
