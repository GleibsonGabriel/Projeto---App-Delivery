<?php
// menu.php

$restaurant_id = $_GET['restaurant_id'];

$menus = [
    1 => [
        ['name' => 'Pizza Margherita', 'description' => 'Pizza com molho de tomate e mussarela', 'price' => 30.00],
        ['name' => 'Lasanha', 'description' => 'Lasanha de carne com molho branco', 'price' => 40.00],
    ],
    2 => [
        ['name' => 'Sushi', 'description' => 'Combo de sushi variado', 'price' => 50.00],
        ['name' => 'Tempura', 'description' => 'Tempura de legumes', 'price' => 35.00],
    ],
    3 => [
        ['name' => 'Churrasco', 'description' => 'Churrasco misto', 'price' => 60.00],
        ['name' => 'Feijoada', 'description' => 'Feijoada completa', 'price' => 45.00],
    ],
];

$selected_menus = $menus[$restaurant_id];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <style>
        body {
            background-color: #3498db; /* Azul */
            color: #fff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        .menu-list {
            list-style: none;
            padding: 0;
        }
        .menu-item {
            background-color: #2980b9; /* Azul mais escuro */
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Menu</h1>
        <ul class="menu-list">
            <?php foreach ($selected_menus as $menu): ?>
                <li class="menu-item">
                    <h2><?php echo $menu['name']; ?></h2>
                    <p><?php echo $menu['description']; ?></p>
                    <p>Preço: R$<?php echo number_format($menu['price'], 2, ',', '.'); ?></p>
                </li>
            <?php endforeach; ?>
        </ul>
        <a href="index.php">Voltar para Restaurantes</a>
    </div>
</body>
</html>
